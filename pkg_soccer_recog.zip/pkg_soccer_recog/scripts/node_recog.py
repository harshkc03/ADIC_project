#!/usr/bin/env python2

# Import necessary stuff
import os
import cv2
import sys
import rospy
import numpy as np
from webots_ros.srv import *
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2.aruco as aruco
from aruco_lib import *

def mask(img,colour):
	'''
	Purpose:
	---
	This function should:
		1. To extract the ball from the image 
	
	Input Arguments:
	---
	`img` :  [ image ]
		warped_image of the vision_sensor_image 
	`colour` :  [ str ]
		colour of the ball
	Returns:
	---
	`shapes` : [ dictonary ]
		Details of the shapes present in the image  
	
	Example call:
	---
	shapes_a = mask(warped_img_a,strclr_a)
	
	'''
	flag_1=0
	shapes={}
	hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
	if(colour=="blue"):
		blue_lower = (94, 80, 2) 
		blue_upper = (120, 255, 255) 
		mask = cv2.inRange(hsv, blue_lower, blue_upper)
		flag_1=1
	if(flag_1==1):
		mask = cv2.erode( mask,None,iterations=2)
		mask = cv2.dilate(mask,None,iterations=2)
		_,thresh=cv2.threshold(mask,110,255,0)
		contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
		
		for i in contours:
			M=cv2.moments(i)
			cX=int(M["m10"]/M["m00"])
			cY=int(M["m01"]/M["m00"])
			if cv2.contourArea(i)>80:
				shapes['Circle'] = [colour,cX,cY]
			
	return shapes

def aruco_detect(img):
	robot_state=0
	det_aruco_list = {}
	det_aruco_list = detect_Aruco(frame)
	print(det_aruco_list)
	if det_aruco_list:
		
		img = mark_Aruco(frame,det_aruco_list)
		robot_state = calculate_Robot_State(img,det_aruco_list)
		print(robot_state)  

	cv2.imwrite("output.jpg",frame)



class cam_access():

	def __init__(self):

		self.camera_name = ''
		self.robot1_name = ''

		# Get the model names
		rospy.Subscriber("/model_name", String, self.name_callback)

		# Wait for sometime
		rospy.sleep(0.1)

		# Display the model names
		rospy.loginfo("Camera name: "+self.camera_name)
		rospy.loginfo("Robot name: "+self.robot1_name)

		# Wait for the service to be available
		rospy.wait_for_service('/'+self.camera_name+'/overhead_camera/enable')

		# Create a service proxy
		self._camera_srv = rospy.ServiceProxy(
			'/'+self.camera_name+'/overhead_camera/enable', set_int)

		# Activate the Webots overhead camera
		self.camera_activate()

		# Variable to hold the camera image
		self.img = np.empty([])  
		
		# Create CvBridge object
		self.bridge = CvBridge()

		# Create a subscriber for the overhead camera feed
		self.image_sub = rospy.Subscriber('/'+self.camera_name+'/overhead_camera/image', Image,self.callback)


	def camera_activate(self):

		# Create srv request object
		req = set_intRequest()

		# Set camera refresh rate as 50 milliseconnds
		req.value = 50

		# Send request to the service
		self._camera_srv.call(req)


	def callback(self,data):

		# Check whether a frame is available
		try:
			cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
		except CvBridgeError as e:
			rospy.logerr(e)
		
		# Store the image
		self.img = cv_image

	def name_callback(self, data):

		# Get the model name
		name = data.data

		# Check and assign the correct names to the variables
		if name.startswith('overhead_cam'):
			self.camera_name = name
		elif name.startswith('Robotino'):
			self.robot1_name = name


if __name__ == "__main__":

	# Initialize ROS node
	rospy.init_node('node_cam_recog', anonymous=True)

	cam_obj = cam_access()

	rospy.sleep(2)
	

	while not rospy.is_shutdown():

		# Get the image
		image = cam_obj.img

		print(image.shape)


		i = mask(image, 'blue')
		print(i['Circle'][0])
		frame = cv2.circle(image,(i['Circle'][1],i['Circle'][2]), 10, (0,0,225), 3)

		try:
			det_aruco_list = {}
			robot_state=0
			det_aruco_list=detect_Aruco(frame)
			# print(det_aruco_list)
			frame = mark_Aruco(frame,det_aruco_list)
			robot_state=calculate_Robot_State(frame,det_aruco_list)
			# print robot_state
			cv2.imwrite("aruco.jpg",frame)
		except:
			pass

		resized = cv2.resize(frame, (540, 360))
		# show the output frame
		cv2.imshow("Frame", resized)

		key = cv2.waitKey(1) & 0xFF
		# if the `q` key was pressed, break from the loop
		if key == ord("q"):
			break
		
		 
	
	# Clean up and exit
	cv2.destroyAllWindows()
